//
//  ParameterTableViewCell.swift
//  WoolwinePlantApp_0.0
//
//  Created by Arun Sreekumar on 08/04/17.
//  Copyright © 2017 Apple Inc. All rights reserved.
//

import UIKit

class ParameterTableViewCell: UITableViewCell {
    
    //Mark: Properties
    @IBOutlet weak var paraNameLabel: UILabel!
    @IBOutlet weak var paraUOMLabel: UILabel!
    @IBOutlet weak var paraMinValueLabel: UILabel!
    @IBOutlet weak var paraMaxValueLabel: UILabel!
    @IBOutlet weak var paraCurrValueTextField: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
